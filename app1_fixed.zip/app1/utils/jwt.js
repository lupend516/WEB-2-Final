const jwt = require("jsonwebtoken");
const User = require("../models/User");

// Генерация токена
const generateToken = (userId) => {
  return jwt.sign({ userId }, process.env.JWT_SECRET, { expiresIn: "1h" });
};

// Верификация токена
const verifyToken = (token) => {
  try {
    return jwt.verify(token, process.env.JWT_SECRET);
  } catch (error) {
    throw new Error("Invalid token");
  }
};

// Middleware для аутентификации
const authMiddleware = async (req, res, next) => {
  const token = req.cookies.jwt;
  if (!token) return res.redirect("/login");

  try {
    const decoded = verifyToken(token);
    req.user = await User.findById(decoded.userId);
    next();
  } catch (error) {
    res.clearCookie("jwt");
    res.redirect("/login");
  }
};

// Middleware для проверки роли администратора
const adminMiddleware = (req, res, next) => {
  if (req.user.role !== "admin") {
    return res.status(403).render("error", { error: "Доступ запрещён" });
  }
  next();
};

module.exports = { generateToken, verifyToken, authMiddleware, adminMiddleware };