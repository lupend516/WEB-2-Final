const mongoose = require("mongoose"); // Подключаем Mongoose для работы с MongoDB
const crypto = require("crypto"); // Подключаем Crypto для хеширования

// Определяем схему для модели Message
const MessageSchema = new mongoose.Schema({
  sender: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }, // Отправитель сообщения (ссылка на модель User)
  receiver: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true }, // Получатель сообщения (ссылка на модель User)
  content: { type: String, required: true }, // Содержимое сообщения
  hash: { type: String, required: true }, // Хеш сообщения для проверки целостности
  createdAt: { type: Date, default: Date.now }, // Дата и время создания сообщения
});

// Метод для генерации хеша сообщения
MessageSchema.methods.generateHash = function () {
  this.hash = crypto.createHash("sha256").update(this.content).digest("hex"); // Генерируем хеш сообщения с помощью SHA-256
};

module.exports = mongoose.model("Message", MessageSchema); // Экспортируем модель Message
