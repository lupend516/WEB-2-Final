const express = require("express");
const connectDB = require("./config/db");
const cookieParser = require("cookie-parser");
const methodOverride = require("method-override");
const path = require("path");
require("dotenv").config();

const app = express();
app.set("view engine", "ejs");

// Middleware
app.use(express.static(path.join(__dirname, "public")));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(methodOverride("_method")); // Для обработки DELETE

// Подключение к базе данных
connectDB();

// Маршруты
const authRoutes = require("./routes/authRoutes");
const messageRoutes = require("./routes/api/messageRoutes");
app.use("/", authRoutes);
app.use("/api/messages", messageRoutes);

// Глобальная обработка ошибок
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render("error", { error: "Ошибка сервера" });
});

// Запуск сервера
const PORT = process.env.PORT || 5001;
app.listen(PORT, () => console.log(`Сервер запущен на порту ${PORT}`));